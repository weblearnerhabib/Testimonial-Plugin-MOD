<?php
/*
Plugin Name: Testimonials Slider BY HABIB
Description: Make Awesome & Attractive Testimonials BY HABIB
Plugin URI: https://github.com/csehabiburr183
Version: 1.6.1
Author: Adnan Habib
Author URI: https://github.com/csehabiburr183
*/

if (!defined('ABSPATH')) exit;


require_once('core/elfsight-plugin.php');

$elfsight_testimonials_slider_config_path = plugin_dir_path(__FILE__) . 'config.json';
$elfsight_testimonials_slider_config = json_decode(file_get_contents($elfsight_testimonials_slider_config_path), true);

new ElfsightTestimonialsSliderPlugin(
    array(
        'name' => esc_html__('Testimonials Slider'),
        'description' => esc_html__('Make Awesome & Attractive Testimonials BY HABIB'),
        'slug' => 'elfsight-testimonials-slider',
        'version' => ': Developer Edition',
        'text_domain' => 'elfsight-testimonials-slider',
        'editor_settings' => $elfsight_testimonials_slider_config['settings'],
        'editor_preferences' => $elfsight_testimonials_slider_config['preferences'],

        'plugin_name' => esc_html__('Testimonials Slider BY HABIB'),
        'plugin_file' => __FILE__,
        'plugin_slug' => plugin_basename(__FILE__),

        'vc_icon' => plugins_url('assets/img/vc-icon.png', __FILE__),
        'menu_icon' => plugins_url('assets/img/menu-icon.png', __FILE__),

        'update_url' => esc_url('https://a.elfsight.com/updates/v1/'),
        'product_url' => esc_url('https://1.envato.market/k2OVL'),
        'helpscout_plugin_id' => 110725
    )
);

?>
